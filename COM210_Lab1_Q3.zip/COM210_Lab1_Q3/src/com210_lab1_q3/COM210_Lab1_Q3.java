
package com210_lab1_q3;

import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;

public class COM210_Lab1_Q3 {//start class

    public static void main(String[] args) 
    {//start main
        Scanner kb = new Scanner(System.in);
        int Length;
        
        System.out.println("How many food items are you purchasing?");
        Length=kb.nextInt();
        String Foods[]=new String[Length];
        double Prices[]=new double[Length];
        StringBuilder reversed = new StringBuilder();
        double total=0;
        double average;
        for(int x=0; x<Foods.length; x++){//start for
            System.out.println("Enter your food items");
            Foods[x]=kb.next();
        }//end for
        for (int x = 0; x < Prices.length; x++) {//start for
            System.out.println("Enter the prices of the food");
            Prices[x] = kb.nextDouble();
        }//end for
        
        for (int i = Foods.length; i > 0; i--) {
          reversed.append(Foods[i - 1]).append(" ");
      };
      
      String[] reversedArray = reversed.toString().split(" ");
        
      System.out.println(Arrays.toString(reversedArray));
      
      for(int i=0; i<Prices.length; i++){
         total = total+Prices[i];
      }
      
      average=total/Prices.length;
      
      for(int i=0; i<Prices.length;i++){
          if(Foods[i].equalsIgnoreCase("peas")){
              System.out.println("The average price is " + average);
          }else{
              System.out.println("no average output");
          }
      }
    }//end main

    
}//end class
