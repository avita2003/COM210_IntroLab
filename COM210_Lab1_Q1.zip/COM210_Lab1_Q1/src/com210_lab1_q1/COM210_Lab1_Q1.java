
package com210_lab1_q1;
import java.util.Scanner;
import java.util.Arrays;

public class COM210_Lab1_Q1 
{//start class

    public static void main(String[] args) 
    {//start main
        Scanner kb = new Scanner(System.in);
        String Foods[] = new String [3];
        double Prices[] = new double [3];
        
        for(int x=0; x<Foods.length; x++)
        {//start for
            System.out.println("Enter the food items");
            Foods[x]=kb.next();
        }//end for
        
        for(int x=0; x<Prices.length; x++)
        {//start for
            System.out.println("Enter the prices of the food");
            Prices[x]=kb.nextDouble();
        }//end for
        
        double average;
        average = (Prices[0]+Prices[1]+Prices[2])/3;
        System.out.println(Arrays.toString(Foods));
        System.out.println("The average price is " + average);
    }//end main
    
}//end class
